import type { GeoPoint } from '../data/locations';
import { loadJson, saveJson } from './persistence';

export const MET_USER_AGENT = 'ArcticGuideApp/1.0 tromso.snowshoe.guide@example.com';

const FORECAST_URL = 'https://api.met.no/weatherapi/locationforecast/2.0/compact';
const REQUEST_TIMEOUT_MS = 12000;

interface MetInstantDetails {
  air_temperature?: number;
  wind_speed?: number;
  wind_from_direction?: number;
}

interface MetTimeseriesEntry {
  time: string;
  data?: {
    instant?: { details?: MetInstantDetails };
    next_1_hours?: {
      summary?: { symbol_code?: string };
      details?: { precipitation_amount?: number };
    };
    next_6_hours?: {
      summary?: { symbol_code?: string };
    };
  };
}

interface MetCompactResponse {
  properties?: {
    meta?: { updated_at?: string };
    timeseries?: MetTimeseriesEntry[];
  };
}

interface ForecastCacheEnvelope {
  fetchedAt: string;
  body: MetCompactResponse;
}

export interface CurrentConditions {
  time: string;
  airTemperatureC: number;
  windSpeedMs: number;
  windFromDirectionDeg: number | null;
  symbolCode: string | null;
  precipitationNextHourMm: number | null;
}

export interface ForecastResult {
  conditions: CurrentConditions;
  fetchedAt: string;
  fromCache: boolean;
  point: GeoPoint;
}

export class ForecastUnavailableError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ForecastUnavailableError';
  }
}

function cacheKey(point: GeoPoint): string {
  return `forecast:v1:${point.latitude.toFixed(4)}:${point.longitude.toFixed(4)}:${Math.round(point.elevationMeters)}`;
}

function isMetResponse(value: unknown): value is MetCompactResponse {
  if (!value || typeof value !== 'object') {
    return false;
  }
  const timeseries = (value as MetCompactResponse).properties?.timeseries;
  return Array.isArray(timeseries) && timeseries.length > 0;
}

function selectEntry(series: MetTimeseriesEntry[], now = Date.now()): MetTimeseriesEntry | null {
  const dated = series
    .map((entry) => ({ entry, time: Date.parse(entry.time) }))
    .filter((item) => Number.isFinite(item.time))
    .sort((a, b) => a.time - b.time);

  if (dated.length === 0) {
    return null;
  }

  let selected = dated[0]?.entry ?? null;
  for (const item of dated) {
    if (item.time <= now) {
      selected = item.entry;
    } else {
      break;
    }
  }
  return selected;
}

function toConditions(body: MetCompactResponse, now = Date.now()): CurrentConditions {
  const series = body.properties?.timeseries ?? [];
  const entry = selectEntry(series, now);
  const details = entry?.data?.instant?.details;
  const temperature = details?.air_temperature;
  const wind = details?.wind_speed;

  if (!entry || typeof temperature !== 'number' || typeof wind !== 'number') {
    throw new ForecastUnavailableError('The forecast did not include temperature and wind.');
  }

  const direction = details?.wind_from_direction;
  const nextHour = entry.data?.next_1_hours;
  const symbol =
    nextHour?.summary?.symbol_code ?? entry.data?.next_6_hours?.summary?.symbol_code ?? null;
  const precipitation = nextHour?.details?.precipitation_amount;

  return {
    time: entry.time,
    airTemperatureC: temperature,
    windSpeedMs: wind,
    windFromDirectionDeg: typeof direction === 'number' ? direction : null,
    symbolCode: symbol,
    precipitationNextHourMm: typeof precipitation === 'number' ? precipitation : null,
  };
}

async function readCache(point: GeoPoint): Promise<ForecastCacheEnvelope | null> {
  const cached = await loadJson<ForecastCacheEnvelope>(cacheKey(point));
  if (!cached || typeof cached.fetchedAt !== 'string' || !isMetResponse(cached.body)) {
    return null;
  }
  return cached;
}

async function fetchLive(point: GeoPoint): Promise<ForecastCacheEnvelope> {
  const params = new URLSearchParams({
    lat: point.latitude.toFixed(4),
    lon: point.longitude.toFixed(4),
    altitude: String(Math.round(point.elevationMeters)),
  });
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(`${FORECAST_URL}?${params.toString()}`, {
      headers: {
        'User-Agent': MET_USER_AGENT,
        Accept: 'application/json',
      },
      signal: controller.signal,
    });

    if (!response.ok) {
      throw new ForecastUnavailableError(`MET Norway responded with ${response.status}.`);
    }

    const body: unknown = await response.json();
    if (!isMetResponse(body)) {
      throw new ForecastUnavailableError('MET Norway returned an empty forecast.');
    }

    const envelope: ForecastCacheEnvelope = {
      fetchedAt: new Date().toISOString(),
      body,
    };
    await saveJson(cacheKey(point), envelope);
    return envelope;
  } finally {
    clearTimeout(timer);
  }
}

export async function fetchForecast(point: GeoPoint): Promise<ForecastResult> {
  try {
    const live = await fetchLive(point);
    return {
      conditions: toConditions(live.body),
      fetchedAt: live.fetchedAt,
      fromCache: false,
      point,
    };
  } catch (error) {
    const cached = await readCache(point);
    if (cached) {
      return {
        conditions: toConditions(cached.body),
        fetchedAt: cached.fetchedAt,
        fromCache: true,
        point,
      };
    }

    if (error instanceof ForecastUnavailableError) {
      throw error;
    }
    throw new ForecastUnavailableError('No forecast is available offline.');
  }
}
