import SunCalc from 'suncalc';

/** Tromsø harbour reference used for civil and nautical twilight. */
export const TROMSO_COORDINATES = {
  latitude: 69.6492,
  longitude: 18.9553,
} as const;

const WIND_CHILL_MIN_KMH = 4.8;
const WIND_CHILL_MAX_TEMP_C = 10;

export type ExposureLevel = 'safe' | 'minor' | 'frostbite' | 'severe';

export interface ExposureAssessment {
  level: ExposureLevel;
  label: string;
  detail: string;
}

export interface TwilightClocks {
  civilDawn: Date | null;
  civilDusk: Date | null;
  nauticalDawn: Date | null;
  nauticalDusk: Date | null;
  solarNoon: Date | null;
}

export type DaylightPhase = 'civil' | 'nautical' | 'night' | 'polar-night';

export interface DaylightStatus {
  clocks: TwilightClocks;
  phase: DaylightPhase;
  label: string;
  detail: string;
  /** 0–1 fill of the active twilight window. 0 when waiting for the next window. */
  progress: number;
  remainingMs: number | null;
  countdownLabel: string;
  solarNoonElevationDeg: number | null;
}

function isValidDate(value: Date | undefined): value is Date {
  return value instanceof Date && !Number.isNaN(value.getTime());
}

function asDate(value: Date | undefined): Date | null {
  return isValidDate(value) ? value : null;
}

/**
 * Environment Canada / JAG-TI wind chill.
 * T is °C and V is km/h.
 * The formula is defined for T <= 10°C and V >= 4.8 km/h. Outside that range
 * the air temperature is returned unchanged.
 */
export function calculateWindChill(tempC: number, windSpeedKmh: number): number {
  if (tempC > WIND_CHILL_MAX_TEMP_C || windSpeedKmh < WIND_CHILL_MIN_KMH) {
    return tempC;
  }
  const windPower = Math.pow(windSpeedKmh, 0.16);
  return 13.12 + 0.6215 * tempC - 11.37 * windPower + 0.3965 * tempC * windPower;
}

export function windChillApplies(tempC: number, windSpeedKmh: number): boolean {
  return tempC <= WIND_CHILL_MAX_TEMP_C && windSpeedKmh >= WIND_CHILL_MIN_KMH;
}

export function metersPerSecondToKmh(metersPerSecond: number): number {
  return metersPerSecond * 3.6;
}

/**
 * Safe above −15°C, minor from −15°C to −27°C, frostbite from −28°C through −40°C,
 * and severe below −40°C.
 */
export function exposureRisk(windChillC: number): ExposureAssessment {
  if (windChillC > -15) {
    return {
      level: 'safe',
      label: 'Safe',
      detail: 'Felt temperature is above −15°C.',
    };
  }
  if (windChillC > -28) {
    return {
      level: 'minor',
      label: 'Minor risk',
      detail: 'Felt temperature is between −15°C and −27°C.',
    };
  }
  if (windChillC >= -40) {
    return {
      level: 'frostbite',
      label: 'Frostbite risk',
      detail: 'Exposed skin can freeze in 10–30 minutes.',
    };
  }
  return {
    level: 'severe',
    label: 'Severe frostbite',
    detail: 'Exposed skin can freeze in under 10 minutes.',
  };
}

const CARDINALS = [
  'N',
  'NNE',
  'NE',
  'ENE',
  'E',
  'ESE',
  'SE',
  'SSE',
  'S',
  'SSW',
  'SW',
  'WSW',
  'W',
  'WNW',
  'NW',
  'NNW',
] as const;

export function windCardinal(degrees: number): string {
  const normalized = ((degrees % 360) + 360) % 360;
  const index = Math.round(normalized / 22.5) % CARDINALS.length;
  return CARDINALS[index] ?? 'N';
}

function readClocks(date: Date): TwilightClocks {
  const times = SunCalc.getTimes(
    date,
    TROMSO_COORDINATES.latitude,
    TROMSO_COORDINATES.longitude,
  );
  return {
    civilDawn: asDate(times.dawn),
    civilDusk: asDate(times.dusk),
    nauticalDawn: asDate(times.nauticalDawn),
    nauticalDusk: asDate(times.nauticalDusk),
    solarNoon: asDate(times.solarNoon),
  };
}

function windowProgress(now: number, start: Date, end: Date): { progress: number; remainingMs: number } {
  const span = end.getTime() - start.getTime();
  const elapsed = now - start.getTime();
  const progress = span <= 0 ? 0 : Math.min(1, Math.max(0, elapsed / span));
  return { progress, remainingMs: Math.max(0, end.getTime() - now) };
}

function solarNoonElevation(noon: Date | null): number | null {
  if (!noon) {
    return null;
  }
  const position = SunCalc.getPosition(
    noon,
    TROMSO_COORDINATES.latitude,
    TROMSO_COORDINATES.longitude,
  );
  if (!Number.isFinite(position.altitude)) {
    return null;
  }
  return (position.altitude * 180) / Math.PI;
}

/**
 * Civil dawn/dusk and nautical twilight for Tromsø, plus a countdown for the
 * window a guide can still use (civil light, otherwise blue hour).
 */
export function tromsoDaylight(date = new Date()): DaylightStatus {
  const clocks = readClocks(date);
  const now = date.getTime();
  const solarNoonElevationDeg = solarNoonElevation(clocks.solarNoon);

  const inactive = {
    clocks,
    progress: 0,
    solarNoonElevationDeg,
  };

  if (
    !clocks.civilDawn &&
    !clocks.civilDusk &&
    !clocks.nauticalDawn &&
    !clocks.nauticalDusk
  ) {
    return {
      ...inactive,
      phase: 'polar-night',
      label: 'Polar night',
      detail: 'The sun stays below nautical twilight. Look for pink and blue scatter around midday.',
      remainingMs: null,
      countdownLabel: 'No nautical twilight today',
    };
  }

  if (clocks.civilDawn && clocks.civilDusk && now >= clocks.civilDawn.getTime() && now <= clocks.civilDusk.getTime()) {
    const window = windowProgress(now, clocks.civilDawn, clocks.civilDusk);
    return {
      ...inactive,
      phase: 'civil',
      label: 'Usable daylight',
      detail: 'Civil twilight. The sun is less than 6° below the horizon.',
      progress: window.progress,
      remainingMs: window.remainingMs,
      countdownLabel: 'Civil dusk',
    };
  }

  if (
    clocks.nauticalDawn &&
    clocks.nauticalDusk &&
    now >= clocks.nauticalDawn.getTime() &&
    now <= clocks.nauticalDusk.getTime()
  ) {
    const window = windowProgress(now, clocks.nauticalDawn, clocks.nauticalDusk);
    return {
      ...inactive,
      phase: 'nautical',
      label: 'Blue hour',
      detail: 'Nautical twilight. Colour is still readable; headlamps should already be out.',
      progress: window.progress,
      remainingMs: window.remainingMs,
      countdownLabel: 'Nautical dusk',
    };
  }

  const nextStart =
    clocks.nauticalDawn && now < clocks.nauticalDawn.getTime()
      ? clocks.nauticalDawn
      : readClocks(new Date(date.getTime() + 24 * 60 * 60 * 1000)).nauticalDawn;

  if (nextStart && nextStart.getTime() > now) {
    return {
      ...inactive,
      phase: 'night',
      label: 'Next blue hour',
      detail: 'Outside nautical twilight. The countdown runs to the next nautical dawn.',
      remainingMs: nextStart.getTime() - now,
      countdownLabel: 'Nautical dawn',
    };
  }

  return {
    ...inactive,
    phase: 'polar-night',
    label: 'Polar night',
    detail: 'No further nautical twilight is available for this date.',
    remainingMs: null,
    countdownLabel: 'No nautical twilight',
  };
}
