import type { ChecklistId } from './checklists';

export type ActivityType = 'snowshoe';
export type ElevationMode = 'trailhead' | 'summit';

export interface GeoPoint {
  latitude: number;
  longitude: number;
  elevationMeters: number;
}

export interface TourLocation {
  id: string;
  name: string;
  place: string;
  area: string;
  durationLabel: string;
  activity: ActivityType;
  checklistId: ChecklistId;
  trailhead: GeoPoint;
  /** Null on rolling terrain where a summit forecast is not used. */
  summit: GeoPoint | null;
}

/**
 * Summit and trailhead share a lat/lon on the Kvaløya peaks.
 * MET Norway separates the two forecasts with the altitude parameter.
 */
export const LOCATIONS: readonly TourLocation[] = [
  {
    id: 'charlottenlund',
    name: 'Tromsøya Easy (2.5h)',
    place: 'Charlottenlund',
    area: 'Tromsøya',
    durationLabel: '2.5h',
    activity: 'snowshoe',
    checklistId: 'standard',
    trailhead: { latitude: 69.664, longitude: 18.94, elevationMeters: 100 },
    summit: null,
  },
  {
    id: 'tverrfjellet',
    name: 'Kvaløya Mountain (5h)',
    place: 'Tverrfjellet',
    area: 'Kattfjordeidet',
    durationLabel: '5h',
    activity: 'snowshoe',
    checklistId: 'mountain',
    trailhead: { latitude: 69.663, longitude: 18.423, elevationMeters: 180 },
    summit: { latitude: 69.663, longitude: 18.423, elevationMeters: 675 },
  },
  {
    id: 'rundfjellet',
    name: 'Kvaløya Mountain (5h)',
    place: 'Rundfjellet',
    area: 'Radio Tower',
    durationLabel: '5h',
    activity: 'snowshoe',
    checklistId: 'mountain',
    trailhead: { latitude: 69.65, longitude: 18.72, elevationMeters: 60 },
    summit: { latitude: 69.65, longitude: 18.72, elevationMeters: 760 },
  },
];

/** Official Statens vegvesen camera viewer. Guides use it for Fv862 Kattfjordeidet. */
export const KATTFJORDEIDET_CAMERAS_URL = 'https://www.vegvesen.no/trafikk/webkamera';

export function getLocation(id: string): TourLocation {
  const found = LOCATIONS.find((location) => location.id === id);
  const fallback = LOCATIONS[0];
  if (found) {
    return found;
  }
  if (!fallback) {
    throw new Error('No tour locations are configured.');
  }
  return fallback;
}

export function pointFor(location: TourLocation, mode: ElevationMode): GeoPoint {
  if (mode === 'summit' && location.summit) {
    return location.summit;
  }
  return location.trailhead;
}
