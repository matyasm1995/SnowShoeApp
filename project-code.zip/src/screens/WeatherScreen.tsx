import { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Linking,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Check, CloudSun, ExternalLink } from 'lucide-react-native';

import { getChecklist } from '../data/checklists';
import {
  KATTFJORDEIDET_CAMERAS_URL,
  LOCATIONS,
  pointFor,
  type ElevationMode,
  type TourLocation,
} from '../data/locations';
import { useChecklist } from '../hooks/useChecklist';
import { useForecast } from '../hooks/useForecast';
import { colors, sharedStyles, spacing, touchTarget } from '../theme';
import {
  calculateWindChill,
  exposureRisk,
  metersPerSecondToKmh,
  tromsoDaylight,
  windCardinal,
  windChillApplies,
  type ExposureLevel,
} from '../utils/environmental';
import {
  formatClock,
  formatCountdown,
  formatMetersPerSecond,
  formatTemperature,
  formatTimestamp,
  humanizeSymbol,
} from '../utils/format';

const EXPOSURE_COLOR: Record<ExposureLevel, string> = {
  safe: colors.textSecondary,
  minor: colors.text,
  frostbite: colors.danger,
  severe: colors.danger,
};

export function WeatherScreen() {
  const [locationId, setLocationId] = useState<string>(LOCATIONS[0]?.id ?? 'charlottenlund');
  const [elevation, setElevation] = useState<ElevationMode>('trailhead');
  const [now, setNow] = useState(() => new Date());

  const location = LOCATIONS.find((item) => item.id === locationId) ?? LOCATIONS[0];
  if (!location) {
    return null;
  }

  return (
    <WeatherBody
      location={location}
      elevation={location.summit ? elevation : 'trailhead'}
      now={now}
      onSelectLocation={(next) => {
        setLocationId(next.id);
        if (!next.summit) {
          setElevation('trailhead');
        }
      }}
      onSelectElevation={setElevation}
      onTick={setNow}
    />
  );
}

function WeatherBody({
  location,
  elevation,
  now,
  onSelectLocation,
  onSelectElevation,
  onTick,
}: {
  location: TourLocation;
  elevation: ElevationMode;
  now: Date;
  onSelectLocation: (location: TourLocation) => void;
  onSelectElevation: (mode: ElevationMode) => void;
  onTick: (date: Date) => void;
}) {
  const point = pointFor(location, elevation);
  const forecast = useForecast(point);
  const checklist = getChecklist(location.checklistId);
  const checks = useChecklist(location.checklistId);
  const daylight = useMemo(() => tromsoDaylight(now), [now]);

  useEffect(() => {
    const timer = setInterval(() => onTick(new Date()), 30000);
    return () => clearInterval(timer);
  }, [onTick]);

  const conditions = forecast.result?.conditions ?? null;
  const windKmh = conditions ? metersPerSecondToKmh(conditions.windSpeedMs) : null;
  const felt =
    conditions && windKmh !== null
      ? calculateWindChill(conditions.airTemperatureC, windKmh)
      : null;
  const chillApplies =
    conditions && windKmh !== null
      ? windChillApplies(conditions.airTemperatureC, windKmh)
      : false;
  const exposure = felt === null ? null : exposureRisk(felt);
  const completed = checklist.items.filter((item) => checks.checked[item.id]).length;
  const symbol = humanizeSymbol(conditions?.symbolCode ?? null);

  return (
    <ScrollView
      style={sharedStyles.screen}
      contentContainerStyle={sharedStyles.content}
      refreshControl={
        <RefreshControl
          refreshing={forecast.loading && forecast.result !== null}
          onRefresh={forecast.reload}
          tintColor={colors.accent}
          colors={[colors.accent]}
          progressBackgroundColor={colors.surface}
        />
      }
    >
      <View style={styles.pillRow}>
        {LOCATIONS.map((item) => {
          const selected = item.id === location.id;
          return (
            <Pressable
              key={item.id}
              accessibilityRole="button"
              accessibilityState={{ selected }}
              onPress={() => onSelectLocation(item)}
              style={({ pressed }) => [
                touchTarget,
                styles.pill,
                selected && styles.pillSelected,
                pressed && styles.pressed,
              ]}
            >
              <Text style={[styles.pillText, selected && styles.pillTextSelected]}>{item.place}</Text>
            </Pressable>
          );
        })}
      </View>

      <View style={sharedStyles.card}>
        <Text style={styles.tourName}>{location.name}</Text>
        <Text style={sharedStyles.secondary}>
          {location.area} · {location.place} · {point.elevationMeters} m
        </Text>
      </View>

      {location.summit ? (
        <View style={styles.toggleRow}>
          <ElevationButton
            label="Bottom / Parking"
            selected={elevation === 'trailhead'}
            onPress={() => onSelectElevation('trailhead')}
          />
          <ElevationButton
            label="Top / Summit"
            selected={elevation === 'summit'}
            onPress={() => onSelectElevation('summit')}
          />
        </View>
      ) : null}

      {forecast.loading && !conditions ? (
        <View style={[sharedStyles.card, touchTarget, styles.loading]}>
          <ActivityIndicator color={colors.accent} size="large" />
          <Text style={sharedStyles.secondary}>Loading MET forecast</Text>
        </View>
      ) : null}

      {forecast.error ? (
        <View style={sharedStyles.card}>
          <Text style={styles.errorText}>{forecast.error}</Text>
        </View>
      ) : null}

      {conditions && felt !== null && exposure ? (
        <View style={styles.metricGrid}>
          <MetricCard label="Real temp" value={formatTemperature(conditions.airTemperatureC)} />
          <MetricCard
            label={chillApplies ? 'Felt wind-chill' : 'Felt temperature'}
            value={formatTemperature(felt)}
            caption={chillApplies ? 'JAG/TI' : 'Wind too light for wind-chill'}
          />
          <MetricCard
            label="Wind speed"
            value={formatMetersPerSecond(conditions.windSpeedMs)}
            unit="m/s"
            caption={symbol}
          />
          <MetricCard
            label="Wind direction"
            value={
              conditions.windFromDirectionDeg === null
                ? '—'
                : windCardinal(conditions.windFromDirectionDeg)
            }
            caption={
              conditions.windFromDirectionDeg === null
                ? 'Direction unavailable'
                : `${Math.round(conditions.windFromDirectionDeg)}°`
            }
          />
        </View>
      ) : null}

      {exposure ? (
        <View
          style={[
            styles.badge,
            exposure.level === 'severe' && styles.badgeSevere,
            exposure.level === 'frostbite' && styles.badgeFrostbite,
          ]}
        >
          <Text
            style={[
              styles.badgeLabel,
              { color: exposure.level === 'severe' ? colors.text : EXPOSURE_COLOR[exposure.level] },
            ]}
          >
            {exposure.label}
          </Text>
          <Text
            style={[
              styles.badgeDetail,
              exposure.level === 'severe' && styles.badgeDetailOnDanger,
            ]}
          >
            {exposure.detail}
          </Text>
        </View>
      ) : null}

      {forecast.result ? (
        <Text style={styles.meta}>
          {forecast.result.fromCache ? 'Cached' : 'Live'} · {formatTimestamp(forecast.result.fetchedAt)}
          {conditions?.precipitationNextHourMm
            ? ` · ${conditions.precipitationNextHourMm.toFixed(1)} mm next hour`
            : ''}
        </Text>
      ) : null}

      <View style={sharedStyles.card}>
        <View style={styles.daylightHeader}>
          <CloudSun color={colors.accent} size={22} />
          <Text style={styles.daylightLabel}>{daylight.label}</Text>
          <Text style={styles.countdown}>
            {formatCountdown(daylight.remainingMs)}
            {daylight.remainingMs !== null ? ` to ${daylight.countdownLabel.toLowerCase()}` : ''}
          </Text>
        </View>
        <View style={styles.track}>
          <View style={[styles.fill, { width: `${Math.round(daylight.progress * 100)}%` }]} />
        </View>
        <Text style={sharedStyles.secondary}>{daylight.detail}</Text>
        <View style={styles.clockRow}>
          <Clock label="Nautical dawn" value={formatClock(daylight.clocks.nauticalDawn)} />
          <Clock label="Civil dawn" value={formatClock(daylight.clocks.civilDawn)} />
          <Clock label="Civil dusk" value={formatClock(daylight.clocks.civilDusk)} />
          <Clock label="Nautical dusk" value={formatClock(daylight.clocks.nauticalDusk)} />
        </View>
      </View>

      <Pressable
        accessibilityRole="link"
        accessibilityLabel="Open Statens vegvesen cameras for Fv862 Kattfjordeidet"
        onPress={() => {
          void Linking.openURL(KATTFJORDEIDET_CAMERAS_URL);
        }}
        style={({ pressed }) => [touchTarget, styles.roadButton, pressed && styles.pressed]}
      >
        <ExternalLink color={colors.background} size={22} />
        <Text style={styles.roadText}>Fv862 Kattfjordeidet — road cameras</Text>
      </Pressable>

      <Text style={sharedStyles.sectionTitle}>{checklist.title}</Text>
      <Text style={sharedStyles.secondary}>
        Today’s kit · {completed}/{checklist.items.length} packed
      </Text>
      {checklist.items.map((item) => {
        const checked = Boolean(checks.checked[item.id]);
        return (
          <Pressable
            key={item.id}
            accessibilityRole="checkbox"
            accessibilityState={{ checked }}
            onPress={() => checks.toggle(item.id)}
            style={({ pressed }) => [touchTarget, styles.checkRow, pressed && styles.pressed]}
          >
            <View style={styles.checkInner}>
              <View style={[styles.box, checked && styles.boxChecked]}>
                {checked ? <Check color={colors.background} size={22} strokeWidth={3} /> : null}
              </View>
              <Text style={[styles.checkLabel, checked && styles.checkLabelDone]}>{item.label}</Text>
            </View>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

function ElevationButton({
  label,
  selected,
  onPress,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={({ pressed }) => [
        touchTarget,
        styles.elevation,
        selected && styles.elevationSelected,
        pressed && styles.pressed,
      ]}
    >
      <Text style={[styles.elevationText, selected && styles.elevationTextSelected]}>{label}</Text>
    </Pressable>
  );
}

function MetricCard({
  label,
  value,
  unit,
  caption,
}: {
  label: string;
  value: string;
  unit?: string;
  caption?: string | null;
}) {
  return (
    <View style={[sharedStyles.card, styles.metric]}>
      <Text style={styles.metricLabel}>{label}</Text>
      <Text style={styles.metricValue} maxFontSizeMultiplier={1.3}>
        {value}
        {unit ? <Text style={styles.metricUnit}> {unit}</Text> : null}
      </Text>
      {caption ? <Text style={styles.metricCaption}>{caption}</Text> : null}
    </View>
  );
}

function Clock({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.clock}>
      <Text style={styles.clockValue}>{value}</Text>
      <Text style={styles.clockLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  pillRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  pill: {
    paddingHorizontal: 16,
    borderRadius: 999,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  pillSelected: {
    borderColor: colors.accent,
    backgroundColor: '#082F49',
  },
  pillText: {
    color: colors.textSecondary,
    fontSize: 16,
    fontWeight: '700',
  },
  pillTextSelected: {
    color: colors.accent,
  },
  tourName: {
    color: colors.text,
    fontSize: 22,
    fontWeight: '700',
  },
  toggleRow: {
    flexDirection: 'row',
    gap: 8,
  },
  elevation: {
    flex: 1,
    paddingHorizontal: 8,
    borderRadius: 14,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  elevationSelected: {
    backgroundColor: colors.accent,
    borderColor: colors.accent,
  },
  elevationText: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  elevationTextSelected: {
    color: colors.background,
  },
  loading: {
    gap: 12,
  },
  errorText: {
    color: colors.danger,
    fontSize: 18,
    fontWeight: '700',
  },
  metricGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.gap,
  },
  metric: {
    width: '48%',
    flexGrow: 1,
    minHeight: 128,
    gap: 6,
  },
  metricLabel: {
    color: colors.textSecondary,
    fontSize: 14,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },
  metricValue: {
    color: colors.text,
    fontSize: 40,
    fontWeight: '700',
  },
  metricUnit: {
    color: colors.textSecondary,
    fontSize: 18,
    fontWeight: '600',
  },
  metricCaption: {
    color: colors.textSecondary,
    fontSize: 14,
  },
  badge: {
    minHeight: 72,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    paddingHorizontal: 16,
    paddingVertical: 12,
    justifyContent: 'center',
  },
  badgeFrostbite: {
    borderColor: colors.danger,
  },
  badgeSevere: {
    backgroundColor: colors.danger,
    borderColor: colors.danger,
  },
  badgeLabel: {
    fontSize: 22,
    fontWeight: '800',
  },
  badgeDetail: {
    color: colors.textSecondary,
    fontSize: 16,
    marginTop: 2,
  },
  badgeDetailOnDanger: {
    color: colors.text,
  },
  meta: {
    color: colors.textSecondary,
    fontSize: 14,
  },
  daylightHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  daylightLabel: {
    color: colors.text,
    fontSize: 18,
    fontWeight: '700',
    flex: 1,
  },
  countdown: {
    color: colors.accent,
    fontSize: 15,
    fontWeight: '700',
    flexShrink: 1,
    textAlign: 'right',
  },
  track: {
    height: 12,
    borderRadius: 999,
    backgroundColor: colors.border,
    overflow: 'hidden',
    marginBottom: 12,
  },
  fill: {
    height: '100%',
    backgroundColor: colors.accent,
  },
  clockRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 12,
  },
  clock: {
    minWidth: 72,
    flexGrow: 1,
  },
  clockValue: {
    color: colors.text,
    fontSize: 18,
    fontWeight: '700',
  },
  clockLabel: {
    color: colors.textSecondary,
    fontSize: 12,
  },
  roadButton: {
    flexDirection: 'row',
    gap: 10,
    backgroundColor: colors.accent,
    borderRadius: 16,
    paddingHorizontal: 16,
  },
  roadText: {
    color: colors.background,
    fontSize: 17,
    fontWeight: '800',
    flexShrink: 1,
    textAlign: 'center',
  },
  checkRow: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 12,
  },
  checkInner: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  box: {
    width: 32,
    height: 32,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: colors.textSecondary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  boxChecked: {
    backgroundColor: colors.accent,
    borderColor: colors.accent,
  },
  checkLabel: {
    color: colors.text,
    fontSize: 18,
    flex: 1,
  },
  checkLabelDone: {
    color: colors.textSecondary,
  },
  pressed: {
    opacity: 0.72,
  },
});
