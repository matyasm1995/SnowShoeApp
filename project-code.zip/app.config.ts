import { withAndroidManifest, type ConfigPlugin } from '@expo/config-plugins';
import type { ConfigContext, ExpoConfig } from 'expo/config';

const HJELP_113_PACKAGE = 'no.norskluftambulanse.hjelp113';

const withEmergencyVisibility: ConfigPlugin = (config) =>
  withAndroidManifest(config, (mod) => {
    const manifest = mod.modResults.manifest;
    manifest.queries = [
      {
        package: [{ $: { 'android:name': HJELP_113_PACKAGE } }],
        intent: [
          {
            action: [{ $: { 'android:name': 'android.intent.action.VIEW' } }],
            data: [{ $: { 'android:scheme': 'android-app' } }],
          },
          {
            action: [{ $: { 'android:name': 'android.intent.action.DIAL' } }],
            data: [{ $: { 'android:scheme': 'tel' } }],
          },
        ],
      },
    ];
    return mod;
  });

export default ({ config }: ConfigContext): ExpoConfig =>
  withEmergencyVisibility({
    ...config,
    name: 'Arctic Snowshoe',
    slug: 'arctic-snowshoe-guide',
    version: '1.0.0',
    orientation: 'portrait',
    userInterfaceStyle: 'dark',
    backgroundColor: '#000000',
    android: {
      ...config.android,
      package: 'no.tromso.snowshoe.guide',
      backgroundColor: '#000000',
      permissions: [],
    },
    extra: {
      ...config.extra,
    },
  });
